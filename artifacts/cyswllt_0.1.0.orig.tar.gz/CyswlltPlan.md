# Cyswllt Plan

## Work Done
-   Initialized project structure.
-   Created `LICENSE` (GPLv3) and `README.md`.
-   Generated application icon.
-   Selected `rclone` as the backend for Google Drive mounting.

## Next Steps
-   [ ] Implement basic GTK4 + Libadwaita window (`main.py`, `window.py`).
-   [ ] Implement `AuthManager` to handle `rclone config` for Google Drive.
-   [ ] Implement `MountManager` to handle `rclone mount`.
-   [ ] Add "Connect" / "Disconnect" UI logic.
-   [ ] Create `.desktop` file for DING integration.
-   [ ] Verify end-to-end functionality.
